Win11 ISO Modifier (Bypassing MS Requirements)

1703_Appraiserress_DLL folder
     contains .dll (Official) from 1703 ISO (Allows upgrading - running setup from inside 'sources' folder)
     SHA-256: 28C76D17B4CCAFF8148CDCE566EE805EB486973DC20CF0A2AF76F659227848CE

BIN folder
     Contains necessary Tools

ISO folder
     Place the ISO that needs to be modified inside this folder
     The original will be retained ( inside the {ISO} folder)... Modified image will be created inside the root folder

Murphy78_Apply-Image-Script folder
     contains @Murphy78's (TPB MDL) newly updated Apply-Image-Sript (1.31)... designed to inject the image (.wim) directly to unformatted drive
     Creates all the necessary partitions
     Usage: Accessed via Shift + F10 (During Setup, at Install prompt) 
     *** See Included .GIF (Notes Folder)

Notes folder
     *** Contains 'NEW' CheckPCStatus
         Check your PC requirement status utilizing WhyNotWin11_v.2.3.2.0 Tool (Updated Tool)

     *** Contains 'NEW' CheckPCStatus2
         Check your PC requirement status utilizing @builtbybel's ReadySunValley 0.61.0 (My preference - More details) 
         - requires Internet Connection

     *** Contains 'NEW' GetToKnowAndTweakPC
         Get to Know and Tweak your PC according to your requirements utilizing @builtbybel's ThisIsWin11 0.70.0 
         - requires Internet Connection

     *** Contains 'NEW' offlineinsiderenroll-2.5.0 courtesy of @Abbodi1706 (MDL)
         as has been brought to my attention recently, the 'DEV' requirement is no longer necessary on builds .65 (and later)
         so have included this for those wishing to change their 'Insider' status after installation
     
     *** Contains Usage Instructions Extended.gif for the above Apply-Image-Sript  (reflecting 1.3.1 update) - Courtesy of @Enthousist (MDL)

     *** also Contains Bypass TPM 2.0 SecureBoot Ram and Storage Checks + Enable Insider 'BETA' Channel.reg 
         (for online use on unsupported systems - Note: Win11 now on BETA channel)

     *** also for completeness I have included AveYo's (@Bau MDL) ToggleDefender.bat
         (as it is advised to turn off defender when running the script - mainly because it is a nuisance)
         Place on desktop double -click as needed to turn off, then turn on again
         SHA-256: 78D78D59F33A18EC2E5FA0C247E57D968A02AF0F1E519F6F65080B744187E44F

ReadMe.txt
     Notes and instructions

Create Modified Win11 (Bypassing MS SB TPM Requirements v. 1.2.2).cmd
     Having read the above ReadMe - Run this (as admin) to apply modificatioms

Note: *** Only available at https://www.upload.ee/files/13387511/Win11_ISO_Modifier--Bypassing-MS-Requirements--2021-08-12.rar.html
          Password: MDL2021

Credits: @mdl052020 (original Script/Idea and for assigning rights), @wilenty (for suggestions - going forward)
         @westyles (for pointing out 'stupid' mistake in script)